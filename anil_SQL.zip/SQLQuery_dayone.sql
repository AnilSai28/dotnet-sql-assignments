
create database db_anil

use db_anil

create table tbl_customers
(
customerid int ,
customername varchar(100),
customercity varchar(100),
customerage int
)

insert tbl_customers values(1001,'john','bgl',25)
insert tbl_customers values(1002,'smith','chennai',30)
insert tbl_customers values(1003,'raj','bgl',26)
insert tbl_customers values(1004,'anil','hyd',25)
insert tbl_customers values(1005,'abhi','delhi',28)
insert tbl_customers values(1006,'sandy',null,30)


select *from tbl_customers

update tbl_customers set customercity='chennai',customerage=35 where customerid=1003

delete tbl_customers where customerid=1002

select*from tbl_customers where customercity='chennai'

select customerid,customername from tbl_customers


sp_help tbl_customers

alter table tbl_customers add customercontactno varchar(100)
select *from tbl_customers

alter table tbl_customers drop column customercontactno

alter table tbl_customers alter column customername varchar(200)
drop table tbl_customers






create table tbl_employees
(
employeeid int,
employeename varchar(100),
employeecity varchar(100),
employeesalary int,
employeeDOJ datetime
)

insert tbl_employees values(1000,'ram','bang',3000,'12/12/2017')
insert tbl_employees values(1001,'anil','chennai',4000,'10/12/2016')
insert tbl_employees values(1002,'bagya','hyd',3000,'04/02/2016')
insert tbl_employees values(1003,'raju','bang',5000,'11/02/2013')
insert tbl_employees values(1004,'mounika','delhi',3500,'05/26/2012')
insert tbl_employees values(1005,'sai','hyd',500,'04/12/2012')
insert tbl_employees values(1006,'harsha','bang',4500,'05/22/2018')
insert tbl_employees values(1007,'priya','chennai',3500,'11/26/2015')
insert tbl_employees values(1008,'sureka','hyd',6500,'02/05/2013')
insert tbl_employees values(1009,'radha','hyd',5000,'06/26/2018')

select *from tbl_employees

update tbl_employees set employeesalary=5000 where employeeid=1005

select employeeid,employeename from tbl_employees

select*from tbl_employees where employeesalary>4000

select*from tbl_employees where employeecity='delhi' and employeesalary>2000

select *from tbl_employees where employeecity='chennai' or employeesalary>4000

select *from tbl_employees where employeecity in('bang','hyd')

insert tbl_employees values(1013,'david','bang',null,'11/26/2013')
select*from tbl_employees

select*from tbl_employees where employeesalary is null

select*from tbl_employees where employeesalary between 3000 and 5000

select*from tbl_employees order by employeesalary desc

select*from tbl_employees order by employeesalary asc

select *from tbl_employees order by employeesalary desc , employeecity desc

select top 1 *from tbl_employees order by employeesalary desc

select top 1 * from tbl_employees where employeeid in(

select top 2 employeeid  from tbl_employees order by employeesalary desc)order by employeesalary asc

select employeeid,len(employeename) from tbl_employees

select employeeid,SUBSTRING(employeename,1,2) from tbl_employees

select employeeid,upper(employeename) as 'mmm', lower(employeecity)from tbl_employees

select employeeid,isnull(employeename,0) from tbl_employees

select*from tbl_employees order by len(employeename) asc

select sum(employeesalary) from tbl_employees where employeecity='bang'

select avg(employeesalary) from tbl_employees 

select max(employeesalary) from tbl_employees 

select min(employeesalary) from tbl_employees 

select count (*) from tbl_employees

select*from tbl_employees

insert tbl_employees values(1020,'rosy','chennai',4000,getdate())

select employeeid,employeename,dateadd(dd,180,employeedoj)from tbl_employees

select employeeid,employeename,datediff(mm,employeedoj,getdate())as 'exp' from tbl_employees

select employeeid,employeename,datename(mm,employeedoj)from tbl_employees

select employeeid,employeename,datepart(mm,employeedoj)from tbl_employees

select datename(dw,'09/28/1996');

select *from tbl_employees

select employeecity,count(*),sum(employeesalary) 
from tbl_employees where employeesalary>3000 group by employeecity
having count(*)>2










