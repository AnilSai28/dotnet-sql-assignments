create table tbl_customerinfoo
(
--(CustomerID(PK) , CustomerName, CustomerCity, CustomerAddress , CustomerMobileNo(U),
-- PAN (U), CustomerPassword , CustomerEmailID (U) )
customerid int identity(1001,1)primary key,
customername varchar(100),
customercity varchar(100),
customeraddress varchar(max),
customermobileno varchar(100),
customerpan varchar(100),
customerpassword varchar(100),
customeremailid varchar(100)
)

insert tbl_customerinfoo values('raj','bang','btm','33023','ty767','er49','raj@gmail.com')

insert tbl_customerinfoo values('anil','delhi','hsr','32456','ki767','lp95','anil@gmail.com')

insert tbl_customerinfoo values('khan','chennai','hsr','32343','lki67','lk95','khan@gmail.com')

insert tbl_customerinfoo values('mouni','chennai','amc','67823','tyju8','erh8','mouni@gmail.com')

insert tbl_customerinfoo values('sai','bang','btm','67523','tyu77','joo45','sai@gmail.com')

select*from tbl_customerinfoo

 --(AccountID(PK),CustomerID(FK),AccountType,AccountBalance,AccountOpenDate,
 -- AccountStatus(Open,Closed,Blocked)) 

 create table accountinfo
 (
 accountid int primary key,
 customerid int 
 foreign key references tbl_customerinfoo(customerid),
 accounttype varchar(100),
 accountbalance varchar(100),
 accountopendate varchar(100),
 accountstatus varchar(100)
 )

 insert accountinfo values(100,1001,'saving','10000','08/21/2016','opened')
insert accountinfo values(101,1002,'current','20000','05/12/2014','closed')
  insert accountinfo values(102,1003,'saving','50000','11/20/2018','opened')
 insert accountinfo values(103,1004,'current','60000','12/02/2017','blocked')
insert accountinfo values(104,1005,'saving','40000','08/14/2018','opened')
select*from accountinfo

create table tbl_transactioninfo
--(TransactionID (PK),AccountID (FK),TransactionType (D,C),Amount (>0),TransactionDate)
(
transactionid int primary key,
accountid int
 foreign key references accountinfo(accountid),
 transactiontype varchar(100),
 amount int not null,
 transactiondate varchar(100)
 )

 insert tbl_transactioninfo values(1,100,'dd',5000,'12/21/2018')
 
 insert tbl_transactioninfo values(2,101,'ch',6000,'05/09/2018')
  insert tbl_transactioninfo values(3,102,'dd',4000,'07/12/2018')
   insert tbl_transactioninfo values(4,103,'dd',1000,'10/18/2017')
    insert tbl_transactioninfo values(5,104,'ch',7000,'09/11/2016')

	select*from tbl_transactioninfo

	--Latest 5 transactions of an account (Enter Account ID as an Input).
	select top 5 * from tbl_transactioninfo order by   transactiondate desc

--ransaction between two dates of an account (Enter Account ID as an Input)
select*from tbl_transactioninfo where transactiondate between '01/01/2018' and '12/01/2018'
(
 select  accountid from tbl_transactioninfo
 )
	
--ccounts of a Customer (Enter Customer ID as an input)

select*from accountinfo where customerid in
(
 select distinct customerid from tbl_customerinfoo
 )

--List of customers(CustomerID,CustomerName,CustomerAddress,CustomerMobileNo,
-- AccountID , AccountBalance)
select tbl_customerinfoo.customerid,tbl_customerinfoo.customername,tbl_customerinfoo.customeraddress,
tbl_customerinfoo.customermobileno,accountinfo.accountid,accountinfo.accountbalance from
tbl_customerinfoo join accountinfo
on tbl_customerinfoo.customerid=accountinfo.customerid

--List of accounts with transactions (AccountID , 
--AccountBalance , TransID , Amount, TransationType).
select accountinfo.accountid,accountinfo.accountbalance,tbl_transactioninfo.transactionid,
tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype from accountinfo join tbl_transactioninfo
on accountinfo.accountid=tbl_transactioninfo.accountid

 --List of customers with accounts and transations (CustomerID,CustomerName,
 --CustomerAddress,CustomerMobileNo,
 -- AccountID , AccountBalance,TransationID , Amount, TransationType)
 select tbl_customerinfoo.customerid,tbl_customerinfoo.customername,tbl_customerinfoo.customeraddress,
 tbl_customerinfoo.customermobileno,accountinfo.accountid,accountinfo.accountbalance,tbl_transactioninfo.transactionid,
 tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype
 from tbl_customerinfoo join accountinfo
 on tbl_customerinfoo.customerid=accountinfo.customerid join tbl_transactioninfo
 on accountinfo.accountid=tbl_transactioninfo.accountid

 --List of Customers who have accounts
 select*from tbl_customerinfoo where customerid   in
(
 select distinct customerid from accountinfo
 )

 
 --List of Customers who have accounts
 select*from tbl_customerinfoo where customerid  not in
(
 select distinct customerid from accountinfo
 

 --List of Account which has transaction.
 select*from accountinfo where accountid   in
(
 select  accountid from tbl_transactioninfo
 )

 --List of Account which has no transaction
  select*from accountinfo where accountid  not in
(
 select  accountid from tbl_transactioninfo
 )
