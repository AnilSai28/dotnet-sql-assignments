create database db_invoices

use db_invoices
create table tbl_customers
(
customeremailid  varchar(100) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customercontactno varchar(15) not null unique,
customeraddress varchar(max) not null
)
--10
insert tbl_customers values('anil@gmail.com','anil','bang','12345','btm')
insert tbl_customers values('raj@gmail.com','raj','delhi','67345','btm')
insert tbl_customers values('mouni@gmail.com','mouni','bang','54345','hsr')
insert tbl_customers values('sai@gmail.com','sai','bang','45345','silkbord')
insert tbl_customers values('king@gmail.com','king','chennai','16645','btm')
insert tbl_customers values('abhi@gmail.com','abhi','bang','12655','hsr')
insert tbl_customers values('nath@gmail.com','nath','bang','89345','btm')
insert tbl_customers values('sureka@gmail.com','sureka','delhi','99345','silkbord')
insert tbl_customers values('pavan@gmail.com','pavan','chennai','12999','hsr')
insert tbl_customers values('anil@gmail.com','anil','bang','12345','btm')

select*from tbl_customers


create table table_items
(
itemid int identity(1,1) primary key,
itemname varchar(100) not null,
itemprice int not null check (itemprice>0)
)
insert table_items values('raj',100)
insert table_items values('anil',300)
insert table_items values('sai',600)
insert table_items values('rsureka',400)
insert table_items values('mouni',500)
insert table_items values('kamal',700)
insert table_items values('bagya',300)
insert table_items values('kohli',800)
insert table_items values('priya',500)
insert table_items values('pavan',800)

select*from table_items


create table tbl_invoices
(
invoiceid int identity(1000,1) primary key,
customeremailid varchar(100) not null
foreign key references tbl_customers(customeremailid),
invoicecity varchar(100) not null,
invoicedate datetime not null
)
insert tbl_invoices values('anil@gmail.com','bang',getdate())
insert tbl_invoices values('raj@gmail.com','chennai',getdate())
insert tbl_invoices values('mouni@gmail.com','delhi',getdate())
insert tbl_invoices values('sai@gmail.com','bang',getdate())
insert tbl_invoices values('king@gmail.com','bang',getdate())
select*from tbl_invoices

create table tbl_invoiceitems
(
invoiceid int foreign key references tbl_invoices(invoiceid),
 itemid int foreign key references table_items(itemid),
 itemquantity int not null check(itemquantity>0),
 itemprice int not null check(itemprice>0),
 primary key (invoiceid,itemid)
 )
 insert tbl_invoiceitems values(1001,3,2,300)
 insert tbl_invoiceitems values(1003,4,3,500)
 insert tbl_invoiceitems values(1004,5,1,200)
 insert tbl_invoiceitems values(1001,2,4,800)
 insert tbl_invoiceitems values(1005,3,2,100)
 insert tbl_invoiceitems values(1003,3,6,700)
 insert tbl_invoiceitems values(1007,4,8,800)
 insert tbl_invoiceitems values(1008,9,1,900)
 insert tbl_invoiceitems values(1004,1,9,200)
 insert tbl_invoiceitems values(1009,2,5,400)
 select*from tbl_invoiceitems



select*from tbl_customers where customeremailid   in
(
 select distinct customeremailid from tbl_invoices
 )

 select*from table_items where itemid not in--remove not
 (
 select distinct itemid from tbl_invoiceitems
 )

 select*from table_items where itemid= --in
 (
 select top 1 itemid from tbl_invoiceitems group by itemid  --with ties 
 order by sum(itemquantity)desc)

 select tbl_invoices.invoiceid,tbl_invoices.invoicecity,tbl_invoices.invoicedate,
 tbl_invoices.customeremailid,tbl_customers.customername from 
 tbl_invoices join tbl_customers
  on tbl_invoices.customeremailid=tbl_customers.customeremailid

   select tbl_invoices.invoiceid,tbl_invoices.customeremailid,tbl_customers.customername,tbl_invoices.invoicecity,tbl_invoices.invoicedate,
tbl_invoiceitems.itemid,tbl_invoiceitems.itemquantity,tbl_invoiceitems.itemprice
from tbl_invoices join tbl_invoiceitems
on tbl_invoices.invoiceid=tbl_invoiceitems.invoiceid
join table_items
on 
tbl_invoiceitems.itemid=table_items.itemid
join 
tbl_customers
on
tbl_invoices.customeremailid=tbl_customers.customeremailid




select tbl_customers.customeremailid,tbl_customers.customername,
tbl_invoices.invoiceid,tbl_invoices.invoicecity from tbl_customers
left outer join tbl_invoices
on
tbl_customers.customeremailid=tbl_invoices.customeremailid


select *from tbl_customers cross join tbl_invoices

